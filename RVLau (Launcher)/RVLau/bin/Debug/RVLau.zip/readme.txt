--------------------
RVLau
--------------------
Re-Volt Auto track launcher (abr. Re-Volt auto launcher, abr. RV Lau)
A small tool coded in VB.NET.
- It allows you to launch a track directly in single mode (you don't have to keep pressing OK or enter or joypad)
- If you're working on a track in 3ds max and have ase2w in your windows directory or folder directory:
It detects if a new .ase file is there, if so, it waits until fully exported from 3ds max then it launches ase2w (optional -morph or -ali) then automatically launches Re-Volt (and single race)
- If you edit directly the world file in Blender, W_Console or TexYUI, it will directly launch Re-Volt then goes to the latest reloaded track.


Support:
��������
http://z3.invisionfree.com/Revolt_Live/


FAQ:
����
? Is it safe?
> I have never learned to program malwares, if you want sources to check I can give them to you (email is k a y [dot] p r o c o m [at] g m a i l . c o m)

? How to use it?
> Just click launch and wait (don't click anything) until you see Single race mode launched

? What about ase?
> It detects the exported ase file then automatically convert it to Re-Volt and launch Re-Volt to the latest single race

? I don't get my exported track! I got another one!!
> Make sure that your last loaded track is the track in 3Ds max / ase exporter

? It doesn't do anything! Where are the clicks?
> The probability of failure is very low, if you witness it too much please report it at the right place

? It keeps pressing enter! what to do?
> Just switch to Re-Volt. Yes, it keeps pressing enter until it goes to the track.
> If you can't, try to quicky close Re-Volt or 'Re-Volt auto launcher'


22:48 06/07/2012
13:14 07/07/2012