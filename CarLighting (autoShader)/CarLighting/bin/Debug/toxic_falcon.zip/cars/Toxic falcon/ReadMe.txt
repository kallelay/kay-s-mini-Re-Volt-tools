Car information
================================================================
Car name : Calligeria Falcon GT
Car Type : Original
Top speed : 40 mph
Rating/Class : 4 (pro)
Installed folder : ...\cars\FalconGT
Description : A car released for Revolt Live Car Competition 2, totally original, with suspensions for more realism.
: 
: 

Author Information
================================================================
Author Name : Halogaland
Email Address : halogaland@orange.fr
Other Info : 

Construction
================================================================
Base : No base
Editor(s) used : MSPaint, and Zmodeler 1.07b

Additional Credits 
================================================================


Copyright / Permissions
================================================================
Do what you want with this car (repaint, conversions for other games, etc...) but you MUST give me credits

