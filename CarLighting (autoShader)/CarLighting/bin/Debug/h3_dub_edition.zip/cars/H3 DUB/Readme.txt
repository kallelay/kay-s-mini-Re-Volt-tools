Car information
================================================================
Car name                : H3 Dub Edition
Car Type  		: Conversion of a car on limewire
Top speed 		: 40 mph
Rating/Class   		: 4 (pro)
Install folder       	: ...\cars\H3 DUB
Install procedure	: 
Description             : Conversion of a car on limewire
 
Author Information
================================================================
Author Name 		: Hotshot
Email Address           : xhotshotx@gmail.com
Misc. Author Info       : 
 
Construction
================================================================
Base           		: Conversion of a car on limewire
Poly Count     		: 8000+ polies for the body
               		: 400+ polies for each wheel
Editor(s) used 		: 
Known Bugs     		: 
 
Additional Credits 
================================================================
Thanks and accolades to all who inspired or helped in your creation
 
Copyright / Permissions
================================================================
Authors (MAY/may NOT) use this Car as a base to build additional cars.  
(One of the following)
You MAY distribute this CAR, provided you include this file, with no 
modifications.  You may distribute this file in any electronic format 
(BBS, Diskette, CD, etc) as long as you include this file intact.
You MAY not distribute this CAR file in any format.
You may do whatever you want with this CAR.
 
Where else to get this CAR
================================================================
FTP sites		:
Website  		:
Other			: