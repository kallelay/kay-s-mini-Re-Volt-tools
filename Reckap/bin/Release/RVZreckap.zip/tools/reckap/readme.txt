A portmanteau of recap and "PACKage" backwards is born the word "r e k c a p" 


REKCAP is a powerful wizard-based tool for Correct packing your track file as well as polishing the current files
Here is what it can do!



[*] Modify track folder name on the fly (as you press keys, the track folder should be correctly renamed)
[*] Modify track name on the fly (same, name in inf changes at the same time you press keys)
[*] Check for Junk files
[*] Add rain/lightning/skybox on the fly
[*] get a review about pickups 
[*] get a review about shading, polygons count and bitmaps
[*] generate mipmaps (bmq and bmr)
[*] generate  a super fancy readme file
[*] resizing a GFX file and applying it correctly
[*] compress into ZIP correctly (You may want to pick which are to pack!)
[*] get a score about how EFFICIENT is your track (it's not how good, it's how efficient in term of resources)


Support:
	http://z3.invisionfree.com/Revolt_Live/
	http://z3.invisionfree.com/Our_Revolt_Pub/
	http://revoltzone.net/

Thanks:	
	Thanks to SebR for his support and ideas!
	Every fellow re-volter, including you


Changelog
*********
rev 3: INF file is no longer edited
rev 2: Pick which files are to zip


Conception et programmation par Kallel A.Y (kay)
Rev 1 Sfax, le 14:38 2015/07/17
Rev 2 Sfax, le 17:28 2015/08/26
Rev 3 Sfax, le 9:41 AM 2020-08-12