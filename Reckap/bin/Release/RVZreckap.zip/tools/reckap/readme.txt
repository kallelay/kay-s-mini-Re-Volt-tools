A portmanteau of recap and "PACKage" backwards is born the word "r e k c a p" 


REKCAP is a powerful wizard-based tool for Correct packing your track file as well as polishing the current files
Here is what it can do!



[*] Modify track folder name on the fly (as you press keys, the track folder should be correctly renamed)
[*] Modify track name on the fly (same, name in inf changes at the same time you press keys)
[*] Check for Junk files
[*] Add rain/lightning/skybox on the fly
[*] get a review about pickups 
[*] get a review about shading, polygons count and bitmaps
[*] generate mipmaps (bmq and bmr)
[*] generate  a super fancy readme file
[*] resizing a GFX file and applying it correctly
[*] compress into ZIP correctly
[*] get a score about how [color=red][b]EFFICIENT[/b][/color] is your track (it's not how good, it's how efficient)


Support:
	http://z3.invisionfree.com/Revolt_Live/
	http://z3.invisionfree.com/Our_Revolt_Pub/
	http://revoltzone.net/



Conception et programmation par Kallel A.Y (kay)
Sfax, le 14:38 2015/07/17
